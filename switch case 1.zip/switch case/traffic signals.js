console.log("traffic signals")
let signal="red"

switch(signal){ 
    case"red":
        console.log("stop")
        break
    case"orange":
        console.log("get ready")
        break
    case"green":
        console.log("go")
        break
    default:
        console.log("invalid signal colour")
}