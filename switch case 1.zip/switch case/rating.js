console.log("product rating")
let rating=3
switch(rating){
    case 1:
        console.log("poor")
        break
    case 2:
        console.log("average")
        break
    case 3:
        console.log("good")
}

