console.log("performing arithmetic operations");
let num1=5
let num2=3
let operator="%"
switch(operator){
    case "+":
        console.log("adittion:",num1+num2)
        break
    case "-":
        console.log("subtraction:",num1-num2)
        break
    case "*":
        console.log("multiplication:",num1*num2)
        break
    case "/":
        console.log("division:",num1/num2)
        break
    default:
        console.log("invalid operator")
}